//
//  ViewController.swift
//  Background Modes Ses
//
//  Created by Kasım Adalan on 14.08.2019.
//  Copyright © 2019 info. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var sesOynatici = AVAudioPlayer()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        do{
            let dosyaYolu = Bundle.main.path(forResource: "music", ofType: ".mp3")
            sesOynatici = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: dosyaYolu!))
            sesOynatici.prepareToPlay()
        }catch{
            print(error.localizedDescription)
        }
        
    }
    @IBAction func basla(_ sender: Any) {
        sesOynatici.play()
    }
    
    @IBAction func dur(_ sender: Any) {
        sesOynatici.stop()
    }
    
}

